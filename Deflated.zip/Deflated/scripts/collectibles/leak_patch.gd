extends Area2D
## Slow-leak patch (sealant blob): stops the air drain for a few seconds.

const Effects = preload("res://scripts/effects/effects.gd")

@export var seal_duration: float = 5.0
@export var pickup_sound: AudioStream

var time: float = randf() * 10.0


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	time += delta
	queue_redraw()


func _on_body_entered(body: Node2D) -> void:
	if body.has_method("apply_leak_seal"):
		body.apply_leak_seal(seal_duration)
		Effects.burst(self, global_position, Color(0.3, 1.0, 0.8), 16, 220.0)
		Effects.play_sfx(self, pickup_sound)
		Effects.popup_text(self, global_position + Vector2(0, -20), "SEALED!", Color(0.4, 1.0, 0.85))
		queue_free()


# Placeholder art: a bobbing teal blob with a glow and shine.
func _draw() -> void:
	var bob := sin(time * 2.5) * 4.0
	draw_set_transform(Vector2(0, bob), 0.0, Vector2.ONE)
	draw_circle(Vector2.ZERO, 24.0 + sin(time * 4.0) * 2.0, Color(0.3, 1.0, 0.8, 0.2))
	draw_circle(Vector2.ZERO, 16.0, Color(0.15, 0.7, 0.6))
	draw_circle(Vector2.ZERO, 12.0, Color(0.3, 0.95, 0.8))
	draw_circle(Vector2(-4, -5), 4.0, Color(1, 1, 1, 0.7))
	# A little "bandage cross" so it reads as a patch
	draw_line(Vector2(-6, 3), Vector2(6, 3), Color(1, 1, 1, 0.8), 2.0)
	draw_line(Vector2(0, -3), Vector2(0, 9), Color(1, 1, 1, 0.8), 2.0)
