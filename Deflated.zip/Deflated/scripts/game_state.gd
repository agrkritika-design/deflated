extends Node
## GameState is an "autoload": Godot creates ONE of these when the game starts
## and keeps it alive across every scene. Any script can use it by name:
##   GameState.play_level(0)
## It handles the level list, death count, best times (saved to disk) and
## fading between scenes.

const LEVELS: Array[String] = [
	"res://scenes/levels/level_1.tscn",
	"res://scenes/levels/level_2.tscn",
	"res://scenes/levels/level_3.tscn",
]
const MENU_SCENE: String = "res://scenes/ui/main_menu.tscn"
const SAVE_PATH: String = "user://deflated_save.cfg"

var current_index: int = 0     # which level we are on (0 = Level 1)
var deaths: int = 0            # deaths on the current level
var best_times: Dictionary = {}  # level index -> best time in seconds

var _fade: ColorRect
var _changing: bool = false


func _ready() -> void:
	# ALWAYS = keep running even when the game is paused (so fades still work).
	process_mode = Node.PROCESS_MODE_ALWAYS
	_load_save()

	# A black-blue rectangle on top of everything, used to fade between scenes.
	var layer := CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	_fade = ColorRect.new()
	_fade.color = Color(0.05, 0.07, 0.15, 0.0)
	layer.add_child(_fade)
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE


# ---------- Going places ----------
func play_level(index: int) -> void:
	current_index = index
	deaths = 0
	change_scene(LEVELS[index])


## Restart the current level but keep the death count.
func retry_level() -> void:
	change_scene(LEVELS[current_index])


func next_level() -> void:
	if current_index + 1 < LEVELS.size():
		play_level(current_index + 1)
	else:
		play_level(0)   # finished the game: start over


func go_to_menu() -> void:
	change_scene(MENU_SCENE)


func is_last_level() -> bool:
	return current_index == LEVELS.size() - 1


func register_death() -> void:
	deaths += 1


## Fade to dark, switch scene, fade back in.
func change_scene(path: String) -> void:
	if _changing:
		return
	_changing = true
	get_tree().paused = false
	var fade_out := create_tween()
	fade_out.tween_property(_fade, "color:a", 1.0, 0.25)
	await fade_out.finished
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	var fade_in := create_tween()
	fade_in.tween_property(_fade, "color:a", 0.0, 0.25)
	await fade_in.finished
	_changing = false


# ---------- Best times ----------
func get_best(index: int) -> float:
	return best_times.get(index, 0.0)


## Saves the time if it is a new record. Returns true when it is.
func submit_time(index: int, time: float) -> bool:
	if index < 0:
		return false
	var old: float = best_times.get(index, 0.0)
	if old <= 0.0 or time < old:
		best_times[index] = time
		_save()
		return true
	return false


func _load_save() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return   # no save file yet
	for i in LEVELS.size():
		best_times[i] = cfg.get_value("best_times", str(i), 0.0)


func _save() -> void:
	var cfg := ConfigFile.new()
	for i in best_times:
		cfg.set_value("best_times", str(i), best_times[i])
	cfg.save(SAVE_PATH)
