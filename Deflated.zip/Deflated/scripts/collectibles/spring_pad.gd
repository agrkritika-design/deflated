extends Area2D
## Spring pad: launches the ball and gives temporary extra-high bounces.

const Effects = preload("res://scripts/effects/effects.gd")

## How much taller bounces become (1.7 = 70% higher).
@export var boost_multiplier: float = 1.7
## How many seconds the boost lasts.
@export var boost_duration: float = 5.0
@export var pickup_sound: AudioStream

var squish: float = 0.0   # 1 = fully squashed, fades back to 0


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if body.has_method("apply_spring_boost"):
		body.apply_spring_boost(boost_multiplier, boost_duration)
		squish = 1.0
		Effects.burst(self, global_position + Vector2(0, -6), Color(1.0, 0.85, 0.2), 10, 220.0)
		Effects.popup_text(self, global_position + Vector2(0, -30), "BOOST!", Color(1.0, 0.9, 0.3))
		Effects.play_sfx(self, pickup_sound)


func _process(delta: float) -> void:
	if squish > 0.0:
		squish = maxf(squish - delta * 4.0, 0.0)
		queue_redraw()


# Placeholder art: base plate, zig-zag spring, bouncy top plate.
func _draw() -> void:
	var top_y := -4.0 + squish * 7.0
	draw_rect(Rect2(-28, 4, 56, 4), Color(0.3, 0.3, 0.35))
	# Zig-zag spring from the base up to the top plate
	var points := PackedVector2Array()
	for i in range(7):
		var x := -10.0 if i % 2 == 0 else 10.0
		points.append(Vector2(x, lerpf(4.0, top_y, i / 6.0)))
	draw_polyline(points, Color(0.7, 0.7, 0.78), 3.0)
	# Top plate
	draw_rect(Rect2(-28, top_y - 5.0, 56, 6), Color(1.0, 0.8, 0.15))
	draw_rect(Rect2(-28, top_y - 5.0, 56, 6), Color(0.5, 0.35, 0.0), false, 2.0)
