extends Node2D
## Shared logic for every real level. Each level scene uses this script and
## only changes the exported settings in the Inspector.
## Needs these child nodes: Player, HUD, ExitDoor.

const Effects = preload("res://scripts/effects/effects.gd")
const LevelCompleteScreen = preload("res://scenes/ui/level_complete.tscn")
const GameOverScreen = preload("res://scenes/ui/game_over.tscn")
const PauseMenuScreen = preload("res://scenes/ui/pause_menu.tscn")

@export var level_title: String = "Level"
## Small hint shown in the bottom-left corner.
@export var hint_text: String = ""
## Background music. Drag a .ogg/.mp3 here (tick "Loop" in its Import tab).
@export var music: AudioStream

@export_group("Storm (drain speeds up over time)")
## Extra drain per second, added every second. 0 = no storm.
@export var drain_ramp_per_second: float = 0.0
## The extra drain stops growing here.
@export var max_extra_drain: float = 10.0

@onready var player = $Player
@onready var hud = $HUD
@onready var exit_door = $ExitDoor

var finished: bool = false
var level_time: float = 0.0
var pause_menu: Node = null


func _ready() -> void:
	# Tell GameState which level this is, so "Next Level" and "Retry" work.
	var index := GameState.LEVELS.find(scene_file_path)
	if index >= 0:
		GameState.current_index = index

	hud.setup(player)
	hud.set_hint(hint_text)
	hud.show_message(level_title, Color.WHITE)
	player.died.connect(_on_player_died)
	exit_door.reached.connect(_on_exit_reached)

	if music != null:
		var m := AudioStreamPlayer.new()
		m.stream = music
		m.volume_db = -8.0
		add_child(m)
		m.play()


func _physics_process(delta: float) -> void:
	if finished or player.is_dead:
		return
	level_time += delta
	hud.set_timer(level_time)
	# Storm: make the drain a little faster every second.
	if drain_ramp_per_second > 0.0:
		player.extra_drain = minf(player.extra_drain + drain_ramp_per_second * delta, max_extra_drain)


## Escape key (the built-in "ui_cancel" action) opens the pause menu.
func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and not finished and not player.is_dead:
		if not is_instance_valid(pause_menu):
			get_viewport().set_input_as_handled()
			pause_menu = PauseMenuScreen.instantiate()
			add_child(pause_menu)


func _on_player_died() -> void:
	if finished:
		return
	GameState.register_death()
	await get_tree().create_timer(0.9).timeout    # let the pop be seen
	var screen = GameOverScreen.instantiate()
	add_child(screen)
	screen.setup(GameState.deaths)


func _on_exit_reached() -> void:
	if finished or player.is_dead:
		return
	finished = true
	player.set_physics_process(false)    # freeze the ball
	Effects.burst(self, player.global_position, Color(1.0, 0.9, 0.3), 50, 400.0)
	Effects.burst(self, player.global_position, Color(0.5, 0.9, 1.0), 30, 300.0)
	await get_tree().create_timer(1.0).timeout
	var new_best := GameState.submit_time(GameState.current_index, level_time)
	var screen = LevelCompleteScreen.instantiate()
	add_child(screen)
	screen.setup(level_title, level_time, GameState.deaths,
			GameState.get_best(GameState.current_index), new_best, GameState.is_last_level())
