extends CharacterBody2D
## The ball. It bounces on its own, and you steer it left and right.
## Air pressure (health) drains constantly. Lower pressure = lower bounces.
## Climb back above the "safe" level after being low and you get a BOUNCE BACK!

const Effects = preload("res://scripts/effects/effects.gd")

# ---------- SIGNALS ----------
signal health_changed(current: float, maximum: float)
signal died
signal bounce_back_triggered
signal damaged

# ---------- GAME FEEL (tweak these in the Inspector!) ----------
@export_group("Health")
@export var max_health: float = 100.0
## Health lost per SECOND.
@export var drain_rate: float = 6.0
## 1.0 = start full. Lower it (e.g. 0.25) to test the Bounce Back quickly.
@export_range(0.0, 1.0) var start_health_ratio: float = 1.0

@export_group("Movement")
@export var move_speed: float = 250.0

@export_group("Bounce")
## Bounce height (pixels) at full health.
@export var max_bounce_height: float = 300.0
## Bounce height (pixels) at nearly zero health.
@export var min_bounce_height: float = 40.0

@export_group("Bounce Back")
## Health ratio below this counts as "low".
@export_range(0.0, 1.0) var low_threshold: float = 0.3
## After being low, reaching this ratio triggers the Bounce Back.
@export_range(0.0, 1.0) var safe_threshold: float = 0.7
## Height (pixels) of the super bounce.
@export var super_bounce_height: float = 650.0
## Seconds of invincibility after a Bounce Back.
@export var invincible_duration: float = 3.0

@export_group("Thorn Hit")
## Seconds of safety after a thorn hit (so one spike can't hit you every frame).
@export var hit_immunity_time: float = 1.0

@export_group("Looks")
## Must match the radius of the CircleShape2D!
@export var radius: float = 16.0

@export_group("Sounds (drag .wav/.ogg files here later)")
@export var sfx_bounce: AudioStream
@export var sfx_bounce_back: AudioStream
@export var sfx_hit: AudioStream
@export var sfx_die: AudioStream

# ---------- STATE ----------
var health: float
var is_dead: bool = false
var is_low: bool = false                # have we been "low" recently?
var super_bounce_pending: bool = false  # do a super bounce on the next floor touch

# Timers (seconds left). When they hit 0 the effect is over.
var leak_time: float = 0.0          # drain stopped (slow-leak patch)
var thorn_time: float = 0.0         # drain faster (thorn hit)
var spring_time: float = 0.0        # extra-high bounces (spring pad)
var invincible_time: float = 0.0    # can't be hurt (Bounce Back)
var hit_cooldown: float = 0.0

## Extra drain added by the level (Storm Climb raises this over time).
var extra_drain: float = 0.0

var thorn_drain_multiplier: float = 1.0
var spring_multiplier: float = 1.0

# Visual state
var squash: float = 0.0             # positive = squashed, negative = stretched
var flash_time: float = 0.0
var flash_total: float = 0.3
var flash_color: Color = Color.WHITE
var shake_time: float = 0.0
var shake_total: float = 0.3
var shake_strength: float = 0.0

var gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")

@onready var camera: Camera2D = $Camera2D


func _ready() -> void:
	health = max_health * start_health_ratio
	is_low = get_health_ratio() <= low_threshold


func _physics_process(delta: float) -> void:
	if is_dead:
		return

	_update_timers(delta)
	_drain_health(delta)
	if is_dead:
		return
	_handle_vertical_movement(delta)
	_handle_horizontal_movement()
	move_and_slide()
	_update_visuals(delta)
	queue_redraw()


# ---------- TIMERS ----------
func _update_timers(delta: float) -> void:
	leak_time = maxf(leak_time - delta, 0.0)
	thorn_time = maxf(thorn_time - delta, 0.0)
	spring_time = maxf(spring_time - delta, 0.0)
	invincible_time = maxf(invincible_time - delta, 0.0)
	hit_cooldown = maxf(hit_cooldown - delta, 0.0)
	if spring_time <= 0.0:
		spring_multiplier = 1.0


# ---------- HEALTH ----------
func _drain_health(delta: float) -> void:
	var rate := drain_rate + extra_drain
	if leak_time > 0.0:
		rate = 0.0                          # sealed! no drain
	elif thorn_time > 0.0:
		rate *= thorn_drain_multiplier      # punctured! drains faster

	health = maxf(health - rate * delta, 0.0)
	health_changed.emit(health, max_health)
	_update_bounce_back_state()

	if health <= 0.0:
		_die()


## Collectibles call this to refill the ball.
func add_health(amount: float) -> void:
	if is_dead:
		return
	health = minf(health + amount, max_health)
	health_changed.emit(health, max_health)
	_update_bounce_back_state()


func get_health_ratio() -> float:
	return health / max_health


## Green when full, yellow in the middle, red when low. The HUD uses this too.
func get_health_color() -> Color:
	var r := get_health_ratio()
	if r > 0.5:
		return Color(1.0, 0.85, 0.15).lerp(Color(0.25, 0.85, 0.3), (r - 0.5) / 0.5)
	return Color(0.9, 0.2, 0.2).lerp(Color(1.0, 0.85, 0.15), r / 0.5)


func _die() -> void:
	is_dead = true
	Effects.burst(self, global_position, get_health_color(), 30, 300.0)
	Effects.play_sfx(self, sfx_die)
	visible = false
	died.emit()


# ---------- BOUNCE BACK ----------
func _update_bounce_back_state() -> void:
	var ratio := get_health_ratio()
	if ratio < low_threshold:
		is_low = true
	elif ratio >= safe_threshold and is_low:
		is_low = false
		_trigger_bounce_back()


func _trigger_bounce_back() -> void:
	invincible_time = invincible_duration
	flash_color = Color(1.0, 0.95, 0.5)
	flash_total = 0.5
	flash_time = flash_total
	if is_on_floor():
		super_bounce_pending = true      # launches on this frame's floor check
	else:
		_launch(super_bounce_height)     # already in the air: launch right now
		squash = -0.4
	Effects.burst(self, global_position, Color(1.0, 0.9, 0.3), 40, 380.0)
	Effects.play_sfx(self, sfx_bounce_back)
	shake_camera(6.0, 0.35)
	bounce_back_triggered.emit()


# ---------- POWER-UPS AND HAZARDS (called by other scripts) ----------
func apply_leak_seal(duration: float) -> void:
	leak_time = duration


func apply_spring_boost(multiplier: float, duration: float) -> void:
	spring_multiplier = multiplier
	spring_time = duration
	if not is_on_floor():
		_launch(_get_bounce_height())    # landing on the pad: boost right away
	squash = -0.3


func hit_by_thorns(damage: float, drain_multiplier: float, duration: float) -> void:
	# Invincible (Bounce Back) or just hit? Then the thorns do nothing.
	if is_dead or invincible_time > 0.0 or hit_cooldown > 0.0:
		return
	health = maxf(health - damage, 0.0)
	thorn_time = duration
	thorn_drain_multiplier = drain_multiplier
	hit_cooldown = hit_immunity_time
	flash_color = Color(1.0, 0.2, 0.2)
	flash_total = 0.3
	flash_time = flash_total
	squash = 0.4
	Effects.burst(self, global_position, Color(1.0, 0.3, 0.3), 14, 250.0)
	Effects.play_sfx(self, sfx_hit)
	Effects.popup_text(self, global_position + Vector2(0, -30), "-%d" % int(damage), Color(1.0, 0.4, 0.4))
	shake_camera(5.0, 0.25)
	health_changed.emit(health, max_health)
	damaged.emit()
	if health <= 0.0:
		_die()


func shake_camera(strength: float, duration: float) -> void:
	shake_strength = strength
	shake_total = duration
	shake_time = duration


# ---------- MOVEMENT ----------
func _handle_vertical_movement(delta: float) -> void:
	if is_on_floor():
		if super_bounce_pending:
			super_bounce_pending = false
			_launch(super_bounce_height)
			squash = -0.4                    # stretch for the big one
		else:
			velocity.y = -_get_bounce_speed()
			squash = 0.3                     # squash on landing
			Effects.burst(self, global_position + Vector2(0, radius), Color(1, 1, 1, 0.8), 4, 70.0)
			Effects.play_sfx(self, sfx_bounce)
	else:
		velocity.y += gravity * delta
		if is_on_ceiling():
			velocity.y = 0.0


func _handle_horizontal_movement() -> void:
	var direction := Input.get_axis("ui_left", "ui_right")
	velocity.x = direction * move_speed


## How high (pixels) the next normal bounce will go.
func _get_bounce_height() -> float:
	var h: float = lerpf(min_bounce_height, max_bounce_height, get_health_ratio())
	if spring_time > 0.0:
		h *= spring_multiplier
	return h


func _get_bounce_speed() -> float:
	return sqrt(2.0 * gravity * _get_bounce_height())


## Sets upward speed so the ball reaches `height` pixels.
func _launch(height: float) -> void:
	velocity.y = -sqrt(2.0 * gravity * height)


# ---------- VISUAL EFFECTS ----------
func _update_visuals(delta: float) -> void:
	squash = move_toward(squash, 0.0, delta * 3.0)
	flash_time = maxf(flash_time - delta, 0.0)

	# Flicker while invincible or just hit.
	if invincible_time > 0.0 or hit_cooldown > 0.0:
		modulate.a = 0.55 + 0.45 * absf(sin(Time.get_ticks_msec() / 1000.0 * 14.0))
	else:
		modulate.a = 1.0

	# Camera shake.
	if shake_time > 0.0:
		shake_time -= delta
		var fade := maxf(shake_time / shake_total, 0.0)
		camera.offset = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * shake_strength * fade
	else:
		camera.offset = Vector2.ZERO


# ---------- DRAWING (placeholder art: swap for a Sprite2D later) ----------
func _draw() -> void:
	var ratio := get_health_ratio()
	var color := get_health_color()

	# Squash & stretch. Low pressure = a flatter, saggier ball.
	var deflate := lerpf(0.78, 1.0, ratio)
	var stretch := clampf(absf(velocity.y) / 1500.0, 0.0, 0.25)
	var sy := clampf(deflate + stretch - squash, 0.5, 1.6)
	var sx := 1.0 / sy
	# Offset keeps the bottom of the ball touching the ground while it squashes.
	draw_set_transform(Vector2(0, radius * (1.0 - sy)), 0.0, Vector2(sx, sy))

	# Gold ring while invincible.
	if invincible_time > 0.0:
		draw_arc(Vector2.ZERO, radius + 7.0, 0.0, TAU, 32, Color(1.0, 0.85, 0.2, 0.9), 3.0)

	draw_circle(Vector2.ZERO, radius + 2.0, color.darkened(0.45))   # outline
	draw_circle(Vector2.ZERO, radius, color)                         # body
	draw_circle(Vector2(-radius * 0.35, -radius * 0.4), radius * 0.28, Color(1, 1, 1, 0.45))  # shine

	# Eyes look where the ball is moving.
	var look := Vector2(clampf(velocity.x / move_speed, -1.0, 1.0), clampf(velocity.y / 600.0, -1.0, 1.0)) * 1.8
	for eye_x in [-5.5, 5.5]:
		var eye := Vector2(eye_x, -2.0)
		draw_circle(eye, 4.5, Color.WHITE)
		draw_circle(eye + look, 2.2, Color(0.1, 0.1, 0.15))

	# Mouth: smile when healthy, frown when low.
	if ratio > 0.35:
		draw_arc(Vector2(0, 2.0), 6.0, PI * 0.2, PI * 0.8, 8, Color(0.1, 0.1, 0.15), 2.0)
	else:
		draw_arc(Vector2(0, 11.0), 5.0, PI * 1.2, PI * 1.8, 8, Color(0.1, 0.1, 0.15), 2.0)

	# Colored flash overlay (Bounce Back = gold, thorn hit = red).
	if flash_time > 0.0:
		draw_circle(Vector2.ZERO, radius, Color(flash_color, flash_time / flash_total * 0.8))

	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
