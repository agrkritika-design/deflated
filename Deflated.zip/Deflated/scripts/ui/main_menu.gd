extends Control
## The main menu: Play, pick a level, or quit.

## Menu music. Drag a .ogg/.mp3 here (tick "Loop" in its Import tab).
@export var music: AudioStream

@onready var play_button: Button = %PlayButton
@onready var quit_button: Button = %QuitButton
@onready var level_buttons: Array = [%Level1Button, %Level2Button, %Level3Button]


func _ready() -> void:
	play_button.pressed.connect(func(): GameState.play_level(0))
	quit_button.pressed.connect(func(): get_tree().quit())
	# A browser tab can't "quit", so hide the button on web builds.
	if OS.has_feature("web"):
		quit_button.hide()

	# Level buttons show the best time for each level.
	for i in level_buttons.size():
		var button: Button = level_buttons[i]
		var best: float = GameState.get_best(i)
		var best_text := "Best %.1fs" % best if best > 0.0 else "Not done"
		button.text = "Level %d\n%s" % [i + 1, best_text]
		button.pressed.connect(GameState.play_level.bind(i))

	play_button.grab_focus()   # so you can press Enter right away

	if music != null:
		var m := AudioStreamPlayer.new()
		m.stream = music
		m.volume_db = -8.0
		add_child(m)
		m.play()
