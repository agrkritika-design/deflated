extends Node
## Small helper functions for particles and sounds.
## "static" means you can call them without making an Effects object:
##   Effects.burst(self, global_position, Color.YELLOW)

## Spawns a one-shot burst of colored square particles (no texture needed).
static func burst(source: Node, pos: Vector2, color: Color, count: int = 16, speed: float = 200.0) -> void:
	var p := CPUParticles2D.new()
	p.one_shot = true
	p.explosiveness = 1.0          # all particles appear at once
	p.amount = count
	p.lifetime = 0.6
	p.direction = Vector2.UP
	p.spread = 180.0               # 180 = shoots in every direction
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.gravity = Vector2(0, 600)
	p.scale_amount_min = 3.0       # particle size in pixels
	p.scale_amount_max = 6.0
	p.color = color
	# Fade out: the color ramp goes from opaque white to transparent white.
	var fade := Gradient.new()
	fade.set_color(0, Color(1, 1, 1, 1))
	fade.set_color(1, Color(1, 1, 1, 0))
	p.color_ramp = fade
	p.z_index = 10
	# Add to the level (not to the player) so the particles stay where they spawned.
	source.get_tree().current_scene.add_child(p)
	p.global_position = pos
	p.emitting = true
	# Clean up after the particles are gone.
	source.get_tree().create_timer(p.lifetime + 0.3).timeout.connect(p.queue_free)


## Plays a sound once. If no sound is assigned (null), it quietly does nothing.
## This is the "sound hook": drag a .wav/.ogg into the Inspector slot and it works.
static func play_sfx(source: Node, stream: AudioStream) -> void:
	if stream == null:
		return
	var a := AudioStreamPlayer.new()
	a.stream = stream
	source.get_tree().current_scene.add_child(a)
	a.play()
	a.finished.connect(a.queue_free)


## Floating text that rises and fades, like "+20" when you pick something up.
static func popup_text(source: Node, pos: Vector2, text: String, color: Color) -> void:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 24)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	label.add_theme_constant_override("outline_size", 6)
	label.z_index = 20
	source.get_tree().current_scene.add_child(label)
	label.global_position = pos - Vector2(20, 12)
	var tween := label.create_tween()
	tween.set_parallel(true)
	tween.tween_property(label, "position:y", label.position.y - 50.0, 0.9)
	tween.tween_property(label, "modulate:a", 0.0, 0.5).set_delay(0.4)
	tween.chain().tween_callback(label.queue_free)
