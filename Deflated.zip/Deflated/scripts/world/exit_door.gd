extends Area2D
## The level exit. Touch it to finish the level.

signal reached

var time: float = 0.0
var used: bool = false


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	time += delta
	queue_redraw()


func _on_body_entered(body: Node2D) -> void:
	if used:
		return
	if body.has_method("add_health"):   # only the player has this method
		used = true
		reached.emit()


# Placeholder art: a glowing purple portal in a golden frame.
func _draw() -> void:
	draw_circle(Vector2.ZERO, 54.0 + sin(time * 3.0) * 4.0, Color(0.7, 0.4, 1.0, 0.18))
	draw_rect(Rect2(-28, -42, 56, 84), Color(1.0, 0.8, 0.2))
	draw_rect(Rect2(-22, -36, 44, 72), Color(0.25, 0.08, 0.5))
	# Rings that shrink toward the center
	for k in range(3):
		var r := 24.0 - fposmod(time * 14.0 + k * 8.0, 24.0)
		draw_arc(Vector2.ZERO, r, 0.0, TAU, 24, Color(0.8, 0.6, 1.0, 0.8), 2.0)
	draw_string(ThemeDB.fallback_font, Vector2(-15, -50), "EXIT", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color.WHITE)
