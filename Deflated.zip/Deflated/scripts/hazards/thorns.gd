@tool
extends Area2D
## Thorns: punctures the ball (chunk of HP loss + faster drain for a few seconds).
## "@tool" lets you see and resize them right in the editor. Change `width` in the Inspector.

@export var width: float = 100.0:
	set(value):
		width = value
		_update_shape()
		queue_redraw()
@export var damage: float = 20.0
@export var drain_multiplier: float = 2.5
@export var drain_duration: float = 4.0

const HEIGHT: float = 24.0
const SPIKE_WIDTH: float = 20.0

var _shape_node: CollisionShape2D


func _ready() -> void:
	_update_shape()
	if Engine.is_editor_hint():
		return    # in the editor we only want the drawing, not the gameplay
	body_entered.connect(_on_body_entered)


## Builds the collision shape from `width` so the hitbox always matches the drawing.
func _update_shape() -> void:
	if not is_inside_tree():
		return
	if _shape_node == null:
		_shape_node = CollisionShape2D.new()
		add_child(_shape_node)
	var rect := RectangleShape2D.new()
	rect.size = Vector2(width, HEIGHT - 6.0)   # a bit smaller than the art = forgiving
	_shape_node.shape = rect


func _on_body_entered(body: Node2D) -> void:
	if body.has_method("hit_by_thorns"):
		body.hit_by_thorns(damage, drain_multiplier, drain_duration)


func _draw() -> void:
	var count := maxi(1, int(width / SPIKE_WIDTH))
	var spike_w := width / count
	var left := -width / 2.0
	draw_rect(Rect2(left, HEIGHT / 2.0 - 4.0, width, 4.0), Color(0.25, 0.05, 0.1))
	for i in count:
		var x0 := left + i * spike_w
		var tri := PackedVector2Array([
			Vector2(x0, HEIGHT / 2.0),
			Vector2(x0 + spike_w / 2.0, -HEIGHT / 2.0),
			Vector2(x0 + spike_w, HEIGHT / 2.0),
		])
		draw_colored_polygon(tri, Color(0.85, 0.2, 0.25))
		draw_polyline(PackedVector2Array([tri[0], tri[1], tri[2]]), Color(0.3, 0.05, 0.1), 2.0)
		draw_circle(tri[1] + Vector2(0, 4), 2.0, Color(1.0, 0.7, 0.7))   # shiny tip
