extends CanvasLayer
## The on-screen display: pressure bar (green/yellow/red, pulses when low),
## status effects, and big pop-up messages.

@onready var bar: ProgressBar = $PressureBar
@onready var bar_label: Label = $PressureLabel
@onready var status_label: Label = $StatusLabel
@onready var message_label: Label = $MessageLabel

var player = null          # set by the level through setup()
var time: float = 0.0
var fill_style: StyleBoxFlat
var message_tween: Tween


func _ready() -> void:
	# The bar's colored part is a StyleBoxFlat. We change its color in code.
	fill_style = bar.get_theme_stylebox("fill") as StyleBoxFlat
	bar.pivot_offset = bar.size / 2.0                 # so it pulses from its center
	message_label.pivot_offset = message_label.size / 2.0
	message_label.modulate.a = 0.0


## The level calls this once so the HUD knows which player to watch.
func setup(p) -> void:
	player = p
	player.health_changed.connect(_on_health_changed)
	player.bounce_back_triggered.connect(_on_bounce_back)
	player.damaged.connect(_on_damaged)
	_on_health_changed(player.health, player.max_health)


func _on_health_changed(current: float, maximum: float) -> void:
	bar.max_value = maximum
	bar.value = current
	bar_label.text = "AIR PRESSURE  %d%%" % int(round(current / maximum * 100.0))


func _process(delta: float) -> void:
	if player == null:
		return
	time += delta
	var ratio: float = player.get_health_ratio()
	var color: Color = player.get_health_color()

	if ratio < 0.3 and not player.is_dead:
		# Low pressure: the bar pulses and flashes brighter.
		var pulse := 1.0 + 0.05 * sin(time * 12.0)
		bar.scale = Vector2(pulse, pulse)
		color = color.lightened(0.3 * (0.5 + 0.5 * sin(time * 12.0)))
	else:
		bar.scale = Vector2.ONE
	fill_style.bg_color = color

	# Status list (only shows effects that are active)
	var lines: PackedStringArray = []
	if player.invincible_time > 0.0:
		lines.append("INVINCIBLE  %.1fs" % player.invincible_time)
	if player.leak_time > 0.0:
		lines.append("LEAK SEALED  %.1fs" % player.leak_time)
	if player.spring_time > 0.0:
		lines.append("SPRING BOOST  %.1fs" % player.spring_time)
	if player.thorn_time > 0.0:
		lines.append("PUNCTURED!  %.1fs" % player.thorn_time)
	if player.extra_drain > 0.05:
		lines.append("STORM DRAIN  +%.1f/s" % player.extra_drain)
	status_label.text = "\n".join(lines)


func _on_bounce_back() -> void:
	show_message("BOUNCE BACK!", Color(1.0, 0.9, 0.3))


func _on_damaged() -> void:
	show_message("OUCH!", Color(1.0, 0.35, 0.35))


## Pops a big message in the middle-top of the screen, then fades it out.
func show_message(text: String, color: Color) -> void:
	if message_tween != null:
		message_tween.kill()
	message_label.text = text
	message_label.modulate = Color(color.r, color.g, color.b, 1.0)
	message_label.scale = Vector2(1.6, 1.6)
	message_tween = create_tween()
	message_tween.tween_property(message_label, "scale", Vector2.ONE, 0.25)
	message_tween.tween_property(message_label, "modulate:a", 0.0, 1.0).set_delay(0.6)


## Shows the level timer in the top-right corner.
func set_timer(t: float) -> void:
	$TimerLabel.text = "%.1f s" % t


## Sets the small hint text in the bottom-left corner.
func set_hint(text: String) -> void:
	$HintLabel.text = text
