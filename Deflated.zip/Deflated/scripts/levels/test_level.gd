extends Node2D
## Test level that shows off everything from Stage 2.

@onready var player = $Player
@onready var hud = $HUD


func _ready() -> void:
	hud.setup(player)                         # tell the HUD who to watch
	player.died.connect(_on_player_died)


func _on_player_died() -> void:
	# Wait a moment so you can see the ball pop, then restart.
	# (A proper Game Over screen comes in the UI stage.)
	await get_tree().create_timer(1.2).timeout
	get_tree().reload_current_scene()
