DEFLATED - Stage 3 (Godot 4.2+)
Open Godot > Import > select project.godot > press F5 (starts at Level 1).
Controls: Left / Right arrow keys.

Levels (scenes/levels/): level_1.tscn  level_2.tscn  level_3.tscn
test_level.tscn is a sandbox with every pickup in one place.
Each level uses scripts/levels/level_base.gd. Change its settings in the Inspector
(title, hint, next level, storm drain ramp). To test a level, open it and press F6.
