extends CanvasLayer
## Shown when the ball runs out of air. The level calls setup() after creating it.

const TIPS: Array[String] = [
	"Tip: low on air? Grab a pump station, then Bounce Back!",
	"Tip: the pump only fills while you stay in its glowing zone.",
	"Tip: a Bounce Back makes you invincible for 3 seconds.",
	"Tip: leak patches stop the drain. Save them for tricky parts.",
	"Tip: the lower your air, the lower you bounce. Plan your jumps!",
]

@onready var stats_label: Label = %StatsLabel
@onready var retry_button: Button = %RetryButton
@onready var menu_button: Button = %MenuButton


func setup(deaths: int) -> void:
	stats_label.text = "Deaths on this level: %d\n\n%s" % [deaths, TIPS.pick_random()]
	retry_button.pressed.connect(GameState.retry_level)
	menu_button.pressed.connect(GameState.go_to_menu)
	retry_button.grab_focus()
