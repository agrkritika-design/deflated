@tool
extends StaticBody2D
## A grassy platform. Set `size` in the Inspector and the collision resizes itself.
## `one_way` = the ball can bounce up through it from below, and land on top.

@export var size: Vector2 = Vector2(200, 24):
	set(value):
		size = value
		_update_shape()
		queue_redraw()
@export var one_way: bool = true:
	set(value):
		one_way = value
		_update_shape()
@export var top_color: Color = Color(0.4, 0.8, 0.35)
@export var body_color: Color = Color(0.55, 0.38, 0.25)

var _shape_node: CollisionShape2D


func _ready() -> void:
	_update_shape()


func _update_shape() -> void:
	if not is_inside_tree():
		return
	if _shape_node == null:
		_shape_node = CollisionShape2D.new()
		add_child(_shape_node)
	var rect := RectangleShape2D.new()
	rect.size = size
	_shape_node.shape = rect
	_shape_node.one_way_collision = one_way


func _draw() -> void:
	var rect := Rect2(-size / 2.0, size)
	var grass_h := minf(8.0, size.y / 2.0)
	# Dirt body + darker bottom edge
	draw_rect(rect, body_color)
	draw_rect(Rect2(rect.position.x, rect.end.y - 4.0, size.x, 4.0), body_color.darkened(0.25))
	# Little dirt specks for texture
	var x := rect.position.x + 20.0
	var i := 0
	while x < rect.end.x - 10.0:
		var y := rect.position.y + grass_h + 6.0 + fposmod(i * 7.0, maxf(size.y - grass_h - 12.0, 1.0))
		draw_circle(Vector2(x, y), 2.5, body_color.darkened(0.15))
		x += 46.0
		i += 1
	# Grass on top
	draw_rect(Rect2(rect.position.x, rect.position.y, size.x, grass_h), top_color)
	draw_rect(Rect2(rect.position.x, rect.position.y + grass_h, size.x, 2.0), top_color.darkened(0.3))
	# Outline
	draw_rect(rect, body_color.darkened(0.5), false, 2.0)
