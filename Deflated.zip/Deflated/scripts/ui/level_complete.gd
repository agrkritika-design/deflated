extends CanvasLayer
## Shown when you reach the exit. The level calls setup() right after creating it.

@onready var title_label: Label = %TitleLabel
@onready var stats_label: Label = %StatsLabel
@onready var next_button: Button = %NextButton
@onready var retry_button: Button = %RetryButton
@onready var menu_button: Button = %MenuButton


func setup(level_title: String, time: float, deaths: int, best: float, new_best: bool, is_last: bool) -> void:
	title_label.text = "YOU WIN!" if is_last else "LEVEL COMPLETE!"
	var text := "%s\nTime: %.1f s" % [level_title, time]
	if new_best:
		text += "   NEW BEST!"
	elif best > 0.0:
		text += "   (Best: %.1f s)" % best
	text += "\nDeaths: %d" % deaths
	stats_label.text = text
	next_button.text = "Play Again" if is_last else "Next Level"

	next_button.pressed.connect(GameState.next_level)
	retry_button.pressed.connect(func(): GameState.play_level(GameState.current_index))
	menu_button.pressed.connect(GameState.go_to_menu)
	next_button.grab_focus()
