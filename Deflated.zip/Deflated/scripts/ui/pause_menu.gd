extends CanvasLayer
## Pause menu. Opens with Escape. Pressing Escape again resumes.

@onready var resume_button: Button = %ResumeButton
@onready var restart_button: Button = %RestartButton
@onready var menu_button: Button = %MenuButton


func _ready() -> void:
	get_tree().paused = true     # freezes everything that is not set to "Always"
	resume_button.pressed.connect(_resume)
	restart_button.pressed.connect(func(): GameState.play_level(GameState.current_index))
	menu_button.pressed.connect(GameState.go_to_menu)
	resume_button.grab_focus()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_resume()


func _resume() -> void:
	get_tree().paused = false
	queue_free()
