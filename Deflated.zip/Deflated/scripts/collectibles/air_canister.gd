extends Area2D
## Air canister: a small refill.

const Effects = preload("res://scripts/effects/effects.gd")

@export var refill_amount: float = 20.0
@export var pickup_sound: AudioStream   # drag a sound here later

var time: float = randf() * 10.0   # random start so canisters don't all bob together


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	time += delta
	queue_redraw()


func _on_body_entered(body: Node2D) -> void:
	if body.has_method("add_health"):
		body.add_health(refill_amount)
		Effects.burst(self, global_position, Color(0.5, 0.85, 1.0), 12, 200.0)
		Effects.play_sfx(self, pickup_sound)
		Effects.popup_text(self, global_position + Vector2(0, -20), "+%d" % int(refill_amount), Color(0.6, 0.9, 1.0))
		queue_free()


# Placeholder art. Replace with a Sprite2D later (and delete this function).
func _draw() -> void:
	var bob := sin(time * 3.0) * 3.0
	draw_set_transform(Vector2(0, bob), 0.0, Vector2.ONE)
	# Soft pulsing glow
	draw_circle(Vector2.ZERO, 20.0 + sin(time * 4.0) * 2.0, Color(0.5, 0.85, 1.0, 0.25))
	# Tank body + outline
	draw_rect(Rect2(-9, -12, 18, 26), Color(0.45, 0.8, 1.0))
	draw_rect(Rect2(-9, -12, 18, 26), Color(0.15, 0.35, 0.6), false, 2.0)
	# Cap and shine
	draw_rect(Rect2(-5, -18, 10, 6), Color(0.6, 0.6, 0.65))
	draw_rect(Rect2(-6, -8, 3, 18), Color(1, 1, 1, 0.5))
	# Label band
	draw_rect(Rect2(-9, 0, 18, 6), Color(1, 1, 1, 0.7))
