# DEFLATED (Godot 4.2+)

Open Godot > Import > pick `project.godot` > press F5. Arrow keys move, Esc pauses.

## Folder structure
```
res://
├── project.godot            (autoload: GameState, main scene: main_menu)
├── scenes/
│   ├── player/player.tscn
│   ├── collectibles/  air_canister, pump_station, spring_pad, leak_patch
│   ├── hazards/thorns.tscn
│   ├── world/  platform.tscn, exit_door.tscn
│   ├── ui/  main_menu, hud, level_complete, game_over, pause_menu
│   └── levels/  level_1, level_2, level_3, test_level (sandbox)
└── scripts/
    ├── game_state.gd        (autoload: levels, deaths, best times, fades)
    ├── player/player.gd
    ├── collectibles/  (one script per pickup)
    ├── hazards/thorns.gd
    ├── world/  platform.gd, exit_door.gd, background.gd
    ├── effects/effects.gd   (particles, floating text, sound helper)
    ├── ui/  hud.gd, main_menu.gd, menu_ball.gd, level_complete.gd, game_over.gd, pause_menu.gd
    └── levels/  level_base.gd, test_level.gd
```

## Game feel: where to tweak
| What | Where | Variable |
|---|---|---|
| Drain speed | Player node, Inspector | `drain_rate` |
| Bounce heights | Player | `max_bounce_height`, `min_bounce_height` |
| Bounce Back trigger | Player | `low_threshold` (0.3), `safe_threshold` (0.7) |
| Super bounce / invincibility | Player | `super_bounce_height`, `invincible_duration` |
| Starting air | Player | `start_health_ratio` |
| Canister / pump refill | each pickup | `refill_amount` |
| Pump hold time | PumpStation | `charge_time`, `grace_time` |
| Spring strength / time | SpringPad | `boost_multiplier`, `boost_duration` |
| Leak patch time | LeakPatch | `seal_duration` |
| Thorn damage / faster drain | Thorns | `damage`, `drain_multiplier`, `drain_duration` |
| Storm difficulty | Level3 root node | `drain_ramp_per_second`, `max_extra_drain` |

## Swapping in sprites and sounds
- Sounds: drag .wav/.ogg into the "Sounds" slots on the Player and on each pickup. Music: the `music` slot on level scenes and the main menu.
- Sprites: delete the `_draw()` function in a script and add a Sprite2D child.
- Fonts / colors: HUD and menus are normal Control nodes, so use the Inspector's Theme Overrides.
