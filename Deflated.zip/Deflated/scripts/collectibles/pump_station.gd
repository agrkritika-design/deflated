extends Area2D
## Pump station: a BIG refill, but you must stay inside the zone for `charge_time` seconds.
## The zone is tall because the ball keeps bouncing. If you leave for longer
## than `grace_time`, the progress resets.

const Effects = preload("res://scripts/effects/effects.gd")

@export var refill_amount: float = 60.0
@export var charge_time: float = 2.0
@export var grace_time: float = 0.5
@export var pickup_sound: AudioStream

var player: Node2D = null   # the ball, while it is inside the zone
var charge: float = 0.0     # seconds spent inside so far
var grace: float = 0.0
var used: bool = false


func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)


func _on_body_entered(body: Node2D) -> void:
	if body.has_method("add_health"):
		player = body


func _on_body_exited(body: Node2D) -> void:
	if body == player:
		player = null
		grace = grace_time


func _physics_process(delta: float) -> void:
	if used:
		return
	if player != null:
		charge += delta
		if charge >= charge_time:
			_finish()
	elif charge > 0.0:
		grace -= delta          # player left: count down before resetting
		if grace <= 0.0:
			charge = 0.0
	queue_redraw()


func _finish() -> void:
	used = true
	player.add_health(refill_amount)
	Effects.burst(self, global_position, Color(0.4, 0.9, 1.0), 30, 320.0)
	Effects.play_sfx(self, pickup_sound)
	Effects.popup_text(self, global_position + Vector2(0, -60), "+%d" % int(refill_amount), Color(0.6, 0.95, 1.0))
	modulate = Color(0.55, 0.55, 0.55, 1.0)   # grey it out
	queue_redraw()


# Placeholder art. The zone is 120 x 160, with the machine sitting at the bottom.
func _draw() -> void:
	var progress := charge / charge_time
	var t := Time.get_ticks_msec() / 1000.0

	if not used:
		# Faint glowing zone
		var glow := 0.07 + (0.12 if player != null else 0.0)
		draw_rect(Rect2(-60, -80, 120, 160), Color(0.4, 0.9, 1.0, glow))
		draw_rect(Rect2(-60, -80, 120, 160), Color(0.4, 0.9, 1.0, 0.5), false, 2.0)
		# Progress bar above the zone
		draw_rect(Rect2(-40, -100, 80, 10), Color(0, 0, 0, 0.6))
		draw_rect(Rect2(-40, -100, 80 * progress, 10), Color(0.4, 0.95, 1.0))
		draw_rect(Rect2(-40, -100, 80, 10), Color.WHITE, false, 2.0)

	# Machine base
	draw_rect(Rect2(-28, 44, 56, 36), Color(0.95, 0.55, 0.2))
	draw_rect(Rect2(-28, 44, 56, 36), Color(0.4, 0.2, 0.05), false, 2.0)
	# Pump column + handle (the handle moves while charging)
	var handle_y := 14.0
	if player != null and not used:
		handle_y -= absf(sin(t * 9.0)) * 12.0
	draw_rect(Rect2(-5, 20, 10, 24), Color(0.6, 0.6, 0.65))
	draw_rect(Rect2(-22, handle_y, 44, 8), Color(0.85, 0.2, 0.2))
	draw_rect(Rect2(-3, handle_y + 8, 6, 20 - (handle_y - 14.0)), Color(0.75, 0.75, 0.8))
	# Gauge with a needle that follows the progress
	draw_circle(Vector2(0, 62), 10.0, Color.WHITE)
	draw_circle(Vector2(0, 62), 10.0, Color(0.2, 0.2, 0.2), false, 2.0)
	var needle := Vector2.from_angle(PI * 0.75 + progress * PI * 1.5) * 7.0
	draw_line(Vector2(0, 62), Vector2(0, 62) + needle, Color(0.9, 0.1, 0.1), 2.0)
