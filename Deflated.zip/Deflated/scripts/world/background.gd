extends Node2D
## Sky gradient, sun, drifting clouds and soft hills, all drawn with code.
## Lives inside a CanvasLayer (layer -10) so it stays behind everything.
## Turn on `storm` for a dark sky with rain and lightning.

@export var storm: bool = false

# Each cloud: Vector3(x, y, scale). Bigger clouds drift faster.
const CLOUDS = [
	Vector3(100, 90, 1.0), Vector3(520, 160, 0.7), Vector3(900, 60, 1.3),
	Vector3(1300, 130, 0.9), Vector3(1700, 80, 1.1),
]

var time: float = 0.0


func _process(delta: float) -> void:
	time += delta
	queue_redraw()


func _draw() -> void:
	var size := get_viewport_rect().size
	var cam_pos := Vector2.ZERO
	var cam := get_viewport().get_camera_2d()
	if cam != null:
		cam_pos = cam.get_screen_center_position()

	# Colors change in storm mode
	var top := Color(0.30, 0.55, 0.90)
	var bottom := Color(0.80, 0.93, 1.0)
	var hill_color := Color(0.55, 0.78, 0.72, 0.55)
	var cloud_color := Color(1, 1, 1, 0.85)
	if storm:
		top = Color(0.12, 0.14, 0.26)
		bottom = Color(0.42, 0.48, 0.58)
		hill_color = Color(0.22, 0.30, 0.36, 0.65)
		cloud_color = Color(0.33, 0.35, 0.44, 0.9)

	# Sky gradient
	draw_polygon(
		PackedVector2Array([Vector2(0, 0), Vector2(size.x, 0), size, Vector2(0, size.y)]),
		PackedColorArray([top, top, bottom, bottom])
	)

	# Sun (not during a storm)
	if not storm:
		draw_circle(Vector2(size.x * 0.82, 90), 60.0, Color(1.0, 0.95, 0.6, 0.35))
		draw_circle(Vector2(size.x * 0.82, 90), 38.0, Color(1.0, 0.95, 0.65))

	var wrap := size.x + 600.0

	# Far hills (slow parallax)
	for i in range(6):
		var hx := fposmod(i * 330.0 - cam_pos.x * 0.15, wrap) - 300.0
		draw_circle(Vector2(hx, size.y + 90.0 - cam_pos.y * 0.05), 250.0, hill_color)

	# Clouds
	var drift := 30.0 if storm else 12.0
	for i in CLOUDS.size():
		var c: Vector3 = CLOUDS[i]
		var x := fposmod(c.x - cam_pos.x * 0.1 * c.z + time * drift * c.z, size.x + 400.0) - 200.0
		var y: float = c.y - cam_pos.y * 0.05
		_draw_cloud(Vector2(x, y), c.z, cloud_color)

	# Rain and lightning
	if storm:
		for i in range(80):
			var rx := fposmod(i * 97.0 - time * 120.0, size.x + 100.0)
			var ry := fposmod(i * 53.0 + time * 800.0 + i * 13.0, size.y)
			draw_line(Vector2(rx, ry), Vector2(rx - 8.0, ry + 22.0), Color(0.8, 0.9, 1.0, 0.45), 1.5)
		var cycle := fposmod(time, 6.0)
		if cycle < 0.12 or (cycle > 0.25 and cycle < 0.32):
			draw_rect(Rect2(Vector2.ZERO, size), Color(1, 1, 1, 0.25))


func _draw_cloud(pos: Vector2, s: float, col: Color) -> void:
	draw_circle(pos, 26.0 * s, col)
	draw_circle(pos + Vector2(28, 8) * s, 20.0 * s, col)
	draw_circle(pos + Vector2(-28, 10) * s, 18.0 * s, col)
	draw_rect(Rect2(pos.x - 28.0 * s, pos.y + 4.0 * s, 56.0 * s, 14.0 * s), col)
