extends Node2D
## The bouncing ball on the main menu. It slowly deflates, then "bounces back"
## to full, just like the real game.

const CYCLE_SECONDS: float = 8.0

var time: float = 0.0
var phase: float = 0.0   # 0 to 1 = one bounce


func _process(delta: float) -> void:
	time += delta
	var air := _get_air()
	var period := lerpf(0.5, 1.0, air)      # low air = quicker, smaller bounces
	phase = fposmod(phase + delta / period, 1.0)
	queue_redraw()


## 1.0 = full, falls to about 0.15, then jumps back to 1.0.
func _get_air() -> float:
	return 1.0 - fposmod(time, CYCLE_SECONDS) / CYCLE_SECONDS * 0.85


func _draw() -> void:
	var size := get_viewport_rect().size
	var ground_y := size.y - 56.0
	var radius := 40.0
	var air := _get_air()

	# Ground
	draw_rect(Rect2(0, ground_y, size.x, 60), Color(0.55, 0.38, 0.25))
	draw_rect(Rect2(0, ground_y, size.x, 10), Color(0.4, 0.8, 0.35))

	# Ball color: green > yellow > red as air falls
	var color: Color
	if air > 0.5:
		color = Color(1.0, 0.85, 0.15).lerp(Color(0.25, 0.85, 0.3), (air - 0.5) / 0.5)
	else:
		color = Color(0.9, 0.2, 0.2).lerp(Color(1.0, 0.85, 0.15), air / 0.5)

	# Parabola: 0 at the ground, peak in the middle of the bounce.
	var height := lerpf(20.0, 190.0, air) * 4.0 * phase * (1.0 - phase)
	var edge := minf(phase, 1.0 - phase)                      # near 0 = touching the ground
	var squash := maxf(0.0, 1.0 - edge / 0.08) * 0.3
	var sy := lerpf(0.8, 1.0, air) - squash
	var sx := 1.0 / sy
	var center := Vector2(size.x * 0.85, ground_y - radius * sy - height)

	draw_set_transform(center, 0.0, Vector2(sx, sy))
	draw_circle(Vector2.ZERO, radius + 4.0, color.darkened(0.45))
	draw_circle(Vector2.ZERO, radius, color)
	draw_circle(Vector2(-14, -16), 11.0, Color(1, 1, 1, 0.45))
	for eye_x in [-14.0, 14.0]:
		draw_circle(Vector2(eye_x, -4.0), 11.0, Color.WHITE)
		draw_circle(Vector2(eye_x + 2.0, -3.0), 5.0, Color(0.1, 0.1, 0.15))
	if air > 0.35:
		draw_arc(Vector2(0, 6.0), 14.0, PI * 0.2, PI * 0.8, 10, Color(0.1, 0.1, 0.15), 3.0)
	else:
		draw_arc(Vector2(0, 28.0), 12.0, PI * 1.2, PI * 1.8, 10, Color(0.1, 0.1, 0.15), 3.0)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
